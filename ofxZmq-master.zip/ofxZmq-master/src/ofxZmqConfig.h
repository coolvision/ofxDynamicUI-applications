#pragma once

#ifndef OFXZMQ_NUM_THREAD
#define OFXZMQ_NUM_THREAD 4
#endif
