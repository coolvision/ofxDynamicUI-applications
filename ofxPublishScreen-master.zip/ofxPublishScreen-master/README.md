#Dependencies

* ofxZmq - [https://github.com/satoruhiga/ofxZmq](https://github.com/satoruhiga/ofxZmq)